gg.alert("⛄ Pubg Mobile Lite VIP Hack Script Version [ 0.18.0 ] 🎎 Subscribe Please If You Using Thanks 🏅 ")

function MN()
Auto = gg.multiChoice({
	" 🏅 Ashwani [ Less Recoil ] ",
	" 🏅 Ashwani [ Auto Headshot ] ",
	" 🏅 Ashwani [ Magic Bullet ] ",
	" 🏅 Ashwani [ Antena Hack ] ",
	" 🏅 Ashwani [ Speed Knok ] ",
	" 🏅 Ashwani [ High Jump ] ",
	" 🏅 Ashwani [ No Recoil ] ",
	" 🏅 Ashwani [ Aimbot ] ",
	" 🏅 Ashwani [ Flash Speed ] ",
	" 🏅 Ashwani [ Speed Dacia ] ",
	" 🏅 Ashwani [ Unlimited Fuel Dacia ] ",
	" 🎨 Wall Hack 845 ",
	" 🎨 Color Yellow 845 ",
	" 🎨 Color Red 845 ",
	" 🎨 Color Blue 845 ",
	" 🎨 Color White 845 ",
	" 🎨 Wall Hack 636 ",
	" 🎨 Color Yellow 636 ",
	" 🎨 Color Red 636 ",
	" 🎨 Wall Hack 625 ",
	" 🎨 Color Hack 625 ",
	" 💘 Exit ",
	
	},nil," ⛄ Pubg Mobile Lite VIP Hack Script Version [ 0.18.0 ] 📀 Subscribe Us On Youtube ")
	
	
if Auto == nil then else
if Auto[1] == true then H1() end
if Auto[2] == true then H2() end
if Auto[3] == true then H3() end
if Auto[4] == true then H4() end 
if Auto[5] == true then H5() end
if Auto[6] == true then H6() end
if Auto[7] == true then H7() end
if Auto[8] == true then H8() end
if Auto[9] == true then H9() end
if Auto[10] == true then H10() end
if Auto[11] == true then H11() end
if Auto[12] == true then H12() end
if Auto[13] == true then H13() end
if Auto[14] == true then H14() end
if Auto[15] == true then H15() end
if Auto[16] == true then H16() end
if Auto[17] == true then H17() end
if Auto[18] == true then H18() end
if Auto[19] == true then H19() end
if Auto[20] == true then H20() end
if Auto [21] == true then H21() end
if Auto[22] == true then Exit() end

end
PUBGMH = -1
end


function H1()
gg.clearResults()
  gg.setRanges(gg.REGION_ANONYMOUS)
  gg.searchNumber('1.5584387e28', gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1)
  gg.getResults(100)
  gg.editAll('0', gg.TYPE_FLOAT)
  gg.clearResults()
  gg.setRanges(gg.REGION_ANONYMOUS)
  gg.searchNumber('1D;0.05000000075F;0.10000000149F;0.55000001192F;9.5F;15.0F', gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1)
  gg.searchNumber('1', gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
  gg.getResults(800)
  gg.editAll('0', gg.TYPE_DWORD)
  gg.toast('Less Recoil Successful!')
  gg.clearResults()
  gg.setVisible(false)
  gg.clearResults()
  end
  
function H2()
gg.setRanges(131108)
    var = gg.getResults(5000)
    gg.clearResults()
    gg.editAll("0",20)
    gg.clearResults()
    gg.setRanges(gg.REGION_BAD)
    gg.searchNumber("-88.66608428955;26:512",gg.POINTER_WRITABLE,false,gg.SIGN_FUZZY_EQUAL,0,-1)
    gg.searchNumber("26",gg.POINTER_WRITABLE,false,gg.SIGN_FUZZY_EQUAL,0,-1)
    var = gg.getResults(2)
    gg.editAll("-460",gg.POINTER_WRITABLE)
    gg.clearResults()
    gg.searchNumber("-88.73961639404;28:512",gg.POINTER_WRITABLE,false,gg.SIGN_FUZZY_EQUAL,0,-1)
    gg.searchNumber("28",gg.POINTER_WRITABLE,false,gg.SIGN_FUZZY_EQUAL,0,-1)
    var = gg.getResults(2)
    gg.editAll("-560",gg.POINTER_WRITABLE)
    gg.clearResults()
    gg.setRanges(gg.REGION_ANONYMOUS)
    gg.searchNumber("9.201618;30.5;25",gg.POINTER_WRITABLE,false,gg.SIGN_FUZZY_EQUAL,0,-1)
    gg.searchNumber("25;30.5",gg.POINTER_WRITABLE,false,gg.SIGN_FUZZY_EQUAL,0,-1)
    var = gg.getResults(10)
    gg.editAll("250",gg.POINTER_WRITABLE)
    gg.clearResults()
    gg.toast("headshot lobby ")
  end
  
function H3() 
gg.setRanges(32)
    gg.searchNumber("9.20161819458;23;25;30.5",16,false,536870912,0,-1)
    gg.searchNumber("25;30.5",16,false,536870912,0,-1)
    gg.getResults(10)
    gg.editAll("251",16)
    gg.toast("magic bullet activated")
    gg.clearResults()
  end
  
function H4() 
gg.toast("Activate again if it doesn't work!")
gg.clearResults()
gg.setRanges(32)
gg.searchNumber("88.50576019287F;87.27782440186F;-100.91194152832F;1F::13", 16, false, 536870912, 0, -1)
gg.searchNumber("88.50576019287F;87.27782440186F;1F", 16, false, 536870912, 0, -1)
gg.getResults(6)
gg.editAll("1.96875;1.96875;999;1.96875;1.96875;999", 16)
gg.clearResults()
gg.toast("Antenna Stick activated!")
end

function H5() 
gg.clearResults()
gg.setRanges(gg.REGION_ANONYMOUS)
gg.searchNumber("0;7.0064923e-45;1;100;1;2,500,000,000.0;0.10000000149;88", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1)
gg.searchNumber("1", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults(100)
gg.editAll("9999", gg.TYPE_FLOAT)
gg.clearResults()
gg.toast("Speed Knock")
end


function H6() 
gg.clearResults()
    gg.setRanges(gg.REGION_ANONYMOUS)
    gg.searchNumber("1;35;443;55;0.57357645035",gg.TYPE_FLOAT,false,gg.SIGN_EQUAL,0,-1)
    gg.searchNumber("1",gg.TYPE_FLOAT,false,gg.SIGN_EQUAL,0,-1)
    gg.getResults(500)
    gg.editAll("3",gg.TYPE_FLOAT)
    gg.setRanges(gg.REGION_ANONYMOUS)
    gg.searchNumber("3;35;443;55;0.57357645035",gg.TYPE_FLOAT,false,gg.SIGN_EQUAL,0,-1)
    gg.searchNumber("443",gg.TYPE_FLOAT,false,gg.SIGN_EQUAL,0,-1)
    gg.getResults(500)
    gg.editAll("2500",gg.TYPE_FLOAT)
    gg.clearResults()
    gg.toast("Jump High No Damage ")
end 

function H7()
  gg.clearResults()
    gg.setRanges(gg.REGION_ANONYMOUS)
    gg.searchNumber("0.20000000298~0.30000001192F;53.0F;30.0F;1.0F::512",gg.TYPE_FLOAT,false,gg.SIGN_EQUAL,0,-1)
    gg.searchNumber("0.20000000298~0.30000001192F;1.0F::512",gg.TYPE_FLOAT,false,gg.SIGN_EQUAL,0,-1)
    gg.getResults(200)
    gg.editAll("1.4012985e-45",gg.TYPE_FLOAT)
    gg.clearResults()
    gg.toast("no recoil ")
end

function H8() 
gg.clearResults()
    gg.setRanges(8)
    gg.searchNumber("360;0.0001;1478828288",16,false,536870912,0,-1)
    gg.searchNumber("0.0001",16,false,536870912,0,-1)
    gg.getResults(100)
    gg.editAll("9999",16)
    gg.toast("aimbot shortrange")
    gg.clearResults()
  end
  
function H9() 
gg.clearResults()
gg.setRanges(32)
gg.searchNumber("1;1;1;0.0001;20;0.0005;0.4::50", 16, false, 536870912, 0, -1)
gg.searchNumber("1", 16, false, 536870912, 0, -1)
gg.getResults(100)
gg.editAll("1.2,5", 16)
gg.toast("Ultra Speed Run ")
  end
  
function H10()
gg.clearResults()
gg.setRanges(32)
gg.searchNumber("0.72727274895;0.34377467632;1::9", 16, false, 536870912, 0, -1)
gg.searchNumber("0.72727274895;0.34377467632::5", 16, false, 536870912, 0, -1)
gg.searchNumber("0.72727274895;0.34377467632::5", 16, false, 536870912, 0, -1)
gg.searchNumber("0.72727274895;0.34377467632::5", 16, false, 536870912, 0, -1)
gg.getResults(50)
gg.editAll("65.241295", 16)
gg.clearResults()
gg.toast("Speed Dacia  activated!")
end

function H11() 
gg.clearResults()
gg.setRanges(32)
gg.searchNumber("0.647058857", 16, false, 536870912, 0, -1)
gg.getResults(10)
gg.editAll("-999", 16)
gg.toast("unlimited fuel!")
end

function H12()
gg.setRanges(gg.REGION_BAD)
gg.searchNumber("5.4049168e21;1.3312335e-43;2.0;7.2303596e-15;2.37549734116:33", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1)
gg.searchNumber('2', gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults(2)
gg.editAll("120", gg.TYPE_FLOAT)
gg.toast('50%%')
gg.clearResults()
gg.searchNumber("2.8866748e-43;1.3912567e-19;1.1202056e-19;2.0:121", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1)
gg.searchNumber("2", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults(3)
gg.editAll("120", gg.TYPE_FLOAT)
gg.clearResults()
gg.toast('wallhack 845 activated')
gg.toast("script By Ashwani Gaming")
end

function H13() 
gg.clearResults()
gg.setRanges(gg.REGION_BAD)
gg.searchNumber(" 1,080,035,863;1,080,033,308;8,200;1,661,702,144:41", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.searchNumber("8200", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults(2)
gg.editAll("8198", gg.TYPE_DWORD)
gg.clearResults()
gg.toast("100%")
gg.toast("yelow colour 845")
end

function H14() 
gg.clearResults()
gg.setRanges(gg.REGION_BAD)
gg.searchNumber("1,080,035,863;1,080,033,308;8,200;1,661,702,144:41", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.searchNumber("8200", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults(2)
gg.editAll("8199", gg.TYPE_DWORD)
gg.clearResults()
gg.toast("100%")
gg.toast("Red colour activated")
end

function H15() 
gg.clearResults()
gg.setRanges(gg.REGION_BAD)
gg.searchNumber("1,080,035,863;1,080,033,308;8,200;1,661,702,144:41 ", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.searchNumber("8200", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults(2)
gg.editAll("3", gg.TYPE_DWORD)
gg.clearResults()
gg.toast("100%")
gg.toast("yelow colour 845")
end

function H16() 
gg.clearResults()
gg.setRanges(gg.REGION_BAD)
gg.searchNumber("1,080,033,303;1,661,599,765;1,661,534,230;1,661,566,999;539,246,604;8,200:37", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.searchNumber("8200", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults(2)
gg.editAll("9", gg.TYPE_DWORD)
gg.clearResults()
gg.toast("white colour activated")
end

function H17()
gg.clearResults()
    gg.setRanges(131072)
    gg.searchNumber("2.718519e-43F;3.7615819e-37F;2.0F;-1.0F;1.0F;-127.0F;0.00999999978F::200",16,false,536870912,0,-1)
    gg.searchNumber(2,16,false,536870912,0,-1)
    gg.getResults(30)
    gg.editAll("120",16)
    gg.clearResults()
    gg.searchNumber("5.8013756e-42F;-5.5695588e-40F;2.0F::100",16,false,536870912,0,-1)
    gg.searchNumber(2,16,false,536870912,0,-1)
    gg.getResults(30)
    gg.editAll("120",16)
    gg.clearResults()
    gg.toast("Activated")
  end
  
function H18() 
gg.searchNumber("1.3912525e-19F;8200;96",gg.TYPE_DWORD,false,gg.SIGN_EQUAL,0,-1)
    gg.searchNumber("8200",gg.TYPE_DWORD,false,gg.SIGN_EQUAL,0,-1)
    gg.getResults(10)
    gg.editAll("6",gg.TYPE_DWORD)
    gg.toast(" Color Yellow ")
end


function H19()
gg.setRanges(gg.REGION_BAD)
gg.searchNumber("8,200;1,194,380,045;1,661,239,308;1,074,794,496;463,008;1,669,332,992:53",gg.TYPE_DWORD, false,gg.SIGN_EQUAL, 0, -1)
gg.searchNumber("8200",gg.TYPE_DWORD, false,gg.SIGN_EQUAL, 0, -1)
gg.getResults(5)
gg.editAll("7",gg.TYPE_DWORD)
gg.clearResults()
gg.toast(" wall hack  activated")
end

function H20()
gg.setRanges(gg.REGION_BAD)
gg.searchNumber("135,215D;4,140D;3.7615819e-37;2::",16,false,536870912,0,-1)
gg.searchNumber("2",16,false,536870912,0,-1)
gg.getResults(10)
gg.editAll("130",16)
gg.clearResults()
gg.setRanges(131072)
gg.searchNumber("194D;3.7615819e-37;2;-1;1;-127::",16,false,536870912,0,-1)
gg.searchNumber("2",16,false,536870912,0,-1)
gg.getResults(10)
gg.editAll("130",16)
gg.toast("Activated")
end

function H21()
gg.clearResults()
    gg.setRanges(131072)
    gg.searchNumber("1.3912525e-19F;8200;96",4,false,536870912,0,-1)
    gg.searchNumber("8200",4,false,536870912,0,-1)
    gg.getResults(10)
    gg.editAll("6",4)
    gg.toast("Active")
  end
  
  
function Exit()
gg.alert(" Please Visit To My Youtube Channel 😎😞 And Subscribe Please I Am Small Youtuber 😭 Please Subscribe To My Youtube Channel [ Ashwani Gaming ] Thanks To Use 💕⛄ ")
gg.setVisible(true)
  os.exit()
end

while true do
 if gg.isVisible(true) then
    PUBGMH = 1
    gg.setVisible(false)
  end
  gg.clearResults()
  if PUBGMH == 1 then
    MN()
  end
end
 
--Ashwani Gaming--

