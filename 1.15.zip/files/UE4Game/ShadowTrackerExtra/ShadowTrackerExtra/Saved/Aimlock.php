
{
    "Config": {
        "0": {
            "AntiCheat": [
                "AntiCheat/null", 
                  "IPAddress_Server/0", 
                    "AntiCheat_IP_Protocol/0",
                      "IP_AntiCheat_Server/0",
        "117.169.101.44" "null",
        "112.25.105.32" "null",
        "112.19.7.64" "null",
        "112.132.32.30" "null",
        "118.212.226.69" "null",
        "118.180.31.221" "null",
        "13.249.11.32" "null",
        "13.249.11.122" "null",
        "99.86.7.121" "null",
        "58.250.137.36" "null",
        "125.39.52.26" "null",
        "58.247.214.47" "null",
        "199.59.242.154" "null",
    }

◆▬▬▬▬▬▬  ❴✪❵  ▬▬▬▬▬▬◆
[JOIN TELEGRAM LUCIFER GAMING]
◆▬▬▬▬▬▬  ❴✪❵  ▬▬▬▬▬▬◆
} 
[AntiCheat]
ServerDown.Port=0
ServerDown.Domain=tencent.com
ServerDown.Domain=proximabeta.com
ServerDown.Domain=qq.com
ServerDown.Domain=qcloud.com
ServerDown.Subdomain=intel.cloud.tencent.com
ServerDown.Subdomain=clientreport.tencent.com
ServerDown.Access=tencent
ServerDown.MessageHit=tencent
ServerDown.Report=tencent
